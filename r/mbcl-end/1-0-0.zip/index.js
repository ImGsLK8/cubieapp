// MangoByte End Mensage (Moved to Cubie)

let data = {
    "hostname":"mangobyte.c2-proxed.cloud.cubie.ml",
    "IP": false
    // Cubie Cloud Server Infrastructure, Inc 
}

console.log("@CubieWeb: 1.0")

/* server: (Based on "Express-Srv")
Credits: https://github.com/gslks/express-server

Express-srv by @GsLKS (Cubie CEO)
Optimized by: *Cubie, inc.
*/

const express = require('express');
const cubie = express();
const port = 8080;
cubie.use(express.static(__dirname + '/front'));
cubie.use((req, res, next) => { 
    res.status(404).send( 
        "<h1>404 Not Found</h1>") 
}) 
cubie.listen(port, () => {
  console.log('@Cubie-System: 1.0 > MangoByte* End Message Server | Port:' + port);
});

// debug:
console.log(data.hostname)